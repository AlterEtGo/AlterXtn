<?php

namespace Ag\Client\Query\Repository;

use Ag\Client\Query\ViewModel\ClientViewModel;
use Ag\Client\Query\ViewModel\ClientViewModelCollection;

interface ClientViewModelRepositoryInterface
{
    /**
     * Inserts or updates a view in the database
     *
     * @param ClientViewModel $clientViewModel
     * @return void
     */
    function save(ClientViewModel $clientViewModel);

    /**
     * Fetches a ClientViewModel by its Client ID
     *
     * @param string $id
     * @return ClientViewModel|null
     */
    function getByClientId($id);

    /**
     * Returns a ClientViewModel collection
     *
     * @param int    $offset
     * @param int    $limit
     * @return ClientViewModelCollection
     */
    function getList($offset, $limit);
}
