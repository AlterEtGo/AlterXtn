<?php

namespace Ag\Client\Ui\WebBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;
use Symfony\Component\DependencyInjection\ContainerBuilder;

class AcmeClientUiWebBundle extends Bundle {}
