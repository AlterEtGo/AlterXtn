<?php

namespace Ag\Client\Ui\WebBundle\Controller;

use Ag\Client\Command\CreateClientCommand;
use Ag\Client\Query\Repository\ClientViewModelRepositoryInterface;
use Ag\Client\Ui\SharedBundle\Util\ControllerUtils;
use Ag\Client\Ui\WebBundle\Form\Type\CreateClientCommandType;
use Symfony\Component\HttpFoundation\Request;

class ClientController
{
    private $utils;
    private $clientViewModelRepository;

    public function __construct(ControllerUtils $utils, ClientViewModelRepositoryInterface $clientViewModelRepository)
    {
        $this->utils = $utils;
        $this->clientViewModelRepository = $clientViewModelRepository;
    }

    public function clientsAction(Request $request)
    {
        $createClientCommand = new CreateClientCommand();
        $form = $this->utils->createForm(new CreateClientCommandType(), $createClientCommand);

        return $this->utils->render('AcmeClientUiWebBundle:Client:clients.html.twig', array(
            'form' => $form->createView(),
        ));
    }

    public function listAction(Request $request)
    {
        $offset =  ((int) $request->query->get('p', 1)) - 1;
        $clientViewModelCollection = $this->clientViewModelRepository->getList($offset, 10);

        return $this->utils->render('AcmeClientUiWebBundle:Client:list.html.twig', array(
            'clientCollection' => $clientViewModelCollection,
        ));
    }
}
