<?php

namespace Ag\Client\Ui\CliBundle\Command;

use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class CreateClientCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName('acme:client:create-client')
            ->setHelp(<<<EOT
The <info>acme:demo:invent-a-joke</info> create a CreateClientCommand and ask the command bus to handle it.
EOT
        )
            ->setDescription('Create a CreateClientCommand and ask the command bus to handle it')
        ;
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $dialog = $this->getHelperSet()->get('dialog');


        $output->writeln('Your client was submitted.');
    }
}
