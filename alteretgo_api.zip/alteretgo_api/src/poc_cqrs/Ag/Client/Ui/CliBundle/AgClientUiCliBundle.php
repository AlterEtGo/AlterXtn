<?php

namespace Ag\Client\Ui\CliBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;
use Symfony\Component\DependencyInjection\ContainerBuilder;

class AcmeClientUiCliBundle extends Bundle {}
