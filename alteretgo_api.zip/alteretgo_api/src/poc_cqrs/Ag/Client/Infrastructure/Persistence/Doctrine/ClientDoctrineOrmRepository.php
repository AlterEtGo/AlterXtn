<?php

namespace Ag\Client\Infrastructure\Persistence\Doctrine;

use Ag\Client\Domain\Model\Client;
use Ag\Client\Domain\Repository\ClientRepositoryInterface;
use Doctrine\ORM\EntityManager;

class ClientDoctrineOrmRepository implements ClientRepositoryInterface
{
    /**
     * @var string
     */
    protected $class;

    /**
     * @var EntityManager
     */
    protected $em;

    /**
     * Constructor
     *
     * @param EntityManager $entityManager
     * @param string        $class         User model class
     */
    public function __construct(EntityManager $entityManager, $class)
    {
        $this->em = $entityManager;
        $this->class = $class;
    }

    /**
     * {@inheritDoc}
     */
    public function add(Client $client)
    {
        $this->em->persist($client);
        $this->em->flush();
    }

    /**
     * {@inheritDoc}
     */
    public function get($id)
    {
        return $this->em->getRepository($this->class)->find($id);
    }
}
