<?php

namespace Ag\Client\Infrastructure\InfrastructureBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class AcmeClientInfrastructureInfrastructureBundle extends Bundle
{
}
