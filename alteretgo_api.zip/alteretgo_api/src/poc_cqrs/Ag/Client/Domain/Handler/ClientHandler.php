<?php

namespace Ag\Client\Domain\Handler;

use Ag\Client\Command\CreateClientCommand;
use Ag\Client\Domain\Model\Client;
use Ag\Client\Domain\Repository\ClientRepositoryInterface;
use LiteCQRS\Bus\IdentityMap\IdentityMapInterface;

class ClientHandler implements ClientHandlerInterface
{
    protected $identityMap;
    protected $clientRepository;

    public function __construct(IdentityMapInterface $identityMap, ClientRepositoryInterface $clientRepository)
    {
        $this->identityMap = $identityMap;
        $this->clientRepository = $clientRepository;
    }

    public function createClient(CreateClientCommand $command)
    {
        // TODO: Factory ?
        $client = new Client();
        $this->identityMap->add($client);

        $client->invent($command->id, $command->content);

        $this->clientRepository->add($client);
    }
}
