<?php

namespace Ag\Client\Domain\Handler;

use Ag\Client\Command\CreateClientCommand;

interface ClientHandlerInterface
{
    function createClient(CreateClientCommand $command);
}
