<?php

namespace Ag\Client\Domain\Event;

class CreatedClientEvent extends DomainEvent
{
    public $id;
    public $content;

    public function getEventName()
    {
        return 'CreatedClient';
    }
}
