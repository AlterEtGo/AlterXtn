<?php

namespace Ag\Client\Domain\Repository;

use Ag\Client\Domain\Model\Client;

interface ClientRepositoryInterface
{
    /**
     * Adds one Client to the repository
     *
     * @param Client $client
     * @return void
     */
    function add(Client $client);

    /**
     * Fetch one Client by its ID (Uuid)
     *
     * @param string $id
     * @return Client|null
     */
    function get($id);
}
