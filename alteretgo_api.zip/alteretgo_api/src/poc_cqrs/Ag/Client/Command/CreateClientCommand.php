<?php

namespace Ag\Client\Command;

use LiteCQRS\DefaultCommand;

class CreateClientCommand extends DefaultCommand
{
    public $id;
    public $content;
}
