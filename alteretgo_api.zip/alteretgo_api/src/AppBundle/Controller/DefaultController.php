<?php

namespace AppBundle\Controller;

use FOS\RestBundle\Controller\Annotations\Get;
use FOS\RestBundle\Controller\Annotations\Post;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Firebase\Token\TokenException;
use Firebase\Token\TokenGenerator;
use Symfony\Component\Validator\Constraints\DateTime;
use Symfony\Component\HttpFoundation\ParameterBag;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\OptionsResolver\Exception\AccessException;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\DependencyInjection\Container;

class DefaultController extends Controller
{
    //const DEFAULT_PATH = '/firebase/user/';

    /**
     * @Route("/", name="homepage")
     */
    public function indexAction(Request $request)
    {
        // replace this example code with whatever you need
        return $this->render('default/index.html.twig', [
            'base_dir' => realpath($this->getParameter('kernel.root_dir') . '/..'),
        ]);
    }



    /**
     * Post to firebase via json using FOSREST
     * @Post("/firebase", name="firebase_post", defaults={"_format":"json"})
     */
    public function firebaseAction(Request $request)
    {
        $firebase = $this->get('app.firebase_connect_controller')->getFireBaseConnection();

        // Decode request content
        $json = json_decode($request->getContent(), true);
        if (!is_array($json) || !isset($json['user'])) {
            throw new BadRequestHttpException('Empty data');
        }
        $request->request = new ParameterBag($json);
        if (
            !isset($request->request->get('user')['name'])
            || !isset($request->request->get('user')['email'])
            || !isset($request->request->get('user')['password'])
        ) {
            throw new BadRequestHttpException('Missing Data');
        }
        //Create new user json obj
        $user = [
            'name' => $request->request->get('user')['name'],
            'email' => $request->request->get('user')['email'],
            'password' => $request->request->get('user')['password']
        ];

        // $firebase->set(self::DEFAULT_PATH.$date, $user);
        $path = $this->getParameter('default_path');
        $firebase->push($path, $user);

        return new Response('<html><body>ok!</body></html>');
    }


    /**
     * @Get("/firebase/get", name="firebase_get", defaults={"_format":"json"})
     */
    public function getUserFirebase(Request $request)
    {
        $path = $this->getParameter('default_path');
        $firebase = $this->get('app.firebase_connect_controller')->getFireBaseConnection();
        $value = $firebase->get($path);
        $data = json_decode($value, true);
        return new JsonResponse($data);
    }

    /**
     * Function to connect to Firebase
     */
    private function getFireBaseConnection(){
        try {
            $generator = new TokenGenerator(self::DEFAULT_TOKEN);
            $token = $generator
                ->setData(array('uid' => 'i2i8nyTlUVfVbm3m5X3TaTjBwkW2'))
                ->create();
        } catch (TokenException $e){
            echo "Error: ".$e->getMessage();
        }
        $firebase = new \Firebase\FirebaseLib(self::DEFAULT_URL, $token);
        return $firebase;
    }
}
