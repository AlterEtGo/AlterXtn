<?php
/**
 * Created by PhpStorm.
 * User: Sarju
 * Date: 15/09/16
 * Time: 14:44
 */

namespace AppBundle\Controller;

use Doctrine\Common\Util\Debug;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Firebase\Token\TokenException;
use Firebase\Token\TokenGenerator;
use Symfony\Component\DependencyInjection\ContainerInterface as Container;


class FirebaseConnectController
{
    //const DEFAULT_URL = 'https://alter-et-go.firebaseio.com/';
    //const DEFAULT_TOKEN = 'chwLVszonv23YK6bqKLhKEwllxeAvY8yH6G40BGD';

    protected $container;

    public function __construct(Container $container)
    {
        $this->Container = $container;

    }

    public function getFireBaseConnection(){

        $default_token = $this->Container->getParameter('default_token');
        $default_url = $this->Container->getParameter('default_url');
        $uid = $this->Container->getParameter('user_id');

        try {
            $generator = new TokenGenerator($default_token);
            $token = $generator
                ->setData(array('uid' => $uid))
                ->create();
        } catch (TokenException $e){
            echo "Error: ".$e->getMessage();
        }
        $firebase = new \Firebase\FirebaseLib($default_url, $token);
        return $firebase;
    }
} 